<div class="footer">
    <footer>
        <p>Cyril Pholoppe &copy; 2023</p>
    </footer>
</div>