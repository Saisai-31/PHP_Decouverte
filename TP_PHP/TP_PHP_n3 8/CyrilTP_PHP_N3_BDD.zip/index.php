<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styleGrid.css">
	<title>TP PHP N3 BDD</title>
</head>
<body>
    <?php
        include_once('entete.php');
        include_once('bodyRequete.php');
        include_once('footer.php');
    ?>
    
</body>
</html>
