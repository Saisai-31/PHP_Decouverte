<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>TP PHP 1</title>
</head>
<body>
<a href="index.php">Accueil</a>
    <a href="exo1.php">Exercice 1: Déclaration et Affichage de Variables</a>
    <a href="exo2.php">Exercice 2: Opérations sur les Variables</a>
    <a href="exo3.php">Exercice 3: Concaténation de Chaînes</a>

    <h1>TP sur les Variables en PHP</h1>
    <ol>
        <li><a href="exo1.php">Déclaration et Affichage de Variables</a></li>
        <li> <a href="exo2.php">Opérations sur les Variables</a></li>
        <li><a href="exo3.php">Concaténation de Chaînes</a></li>
    </ol>

    
   
    

   

</body>
</html>