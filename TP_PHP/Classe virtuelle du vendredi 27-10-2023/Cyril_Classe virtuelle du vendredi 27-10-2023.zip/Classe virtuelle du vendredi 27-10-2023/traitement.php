<?php
foreach($_POST as $name=>$value){
    echo $name."=".$value."<br>";
}
?>