<?php
foreach($_POST as $name=>$value){
    echo $name."=".$value."<br>";
}

var_dump($_POST)."<br>";

?>