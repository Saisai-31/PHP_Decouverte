    <header>
        <nav>
            <a href="boucles.php">Accueil</a>
        </nav>
    </header> 
